//
//  ViewController.swift
//  Shake and Go
//
//  Created by Tugce Tekerlekci on 7/7/16.
//  Copyright © 2016 Tugce Tekerlekci. All rights reserved.
//

import UIKit
import CoreData
import Social

var cityArray:[String]=[]
var mustSeePlaces:[String]=[]
var adress:[String] = []

class ViewController: UIViewController {

   
    
    @IBAction func shareSocialMedia(sender: AnyObject) {
    
        //print("I am here")
        
        twitter.hidden = false
        facebook.hidden = false
    
    }
    
    
    @IBAction func twitterButtonFunc(sender: AnyObject) {
        let vc = SLComposeViewController(forServiceType: SLServiceTypeTwitter)
        vc.addURL(NSURL(string: "http://www.tugcetekerlekci.com"))
        presentViewController(vc, animated: true, completion: nil)
        vc.setInitialText("Shake and discover said to me go to " + cityLabel.text! + "today!")
       
    
    }
 
    @IBAction func facebookButtonFunc(sender: AnyObject) {
        //that directly shares image on facebook
        let vc = SLComposeViewController(forServiceType: SLServiceTypeFacebook)
        
        vc.setInitialText("Shared with Shake and Discover")
        vc.addURL(NSURL(string: "http://www.tugcetekerlekci.com"))
        
       //vc.addImage(UIImage(named: "IMG_7893.JPG")!)
        presentViewController(vc, animated: true, completion: nil)
    
    }
        
    @IBOutlet var mustPlaceLabel: UILabel!
    @IBOutlet var twitter: UIButton!
    
    @IBOutlet var facebook: UIButton!
    
    @IBOutlet var shareSocialMedia: UIButton!
    
    
    @IBOutlet var showMap: UIButton!
    
    @IBOutlet var mustSeePlace: UIButton!
    
    
    @IBOutlet var cityLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let appDel:AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        
        let context:NSManagedObjectContext = appDel.managedObjectContext
        
        /*
        var newCity = NSEntityDescription.insertNewObjectForEntityForName("CityInfo", inManagedObjectContext: context)
       newCity.setValue("Washington", forKey: "city")
       newCity.setValue("White House", forKey: "mustSeePlace")
       newCity.setValue("1600 Pennsylvania Ave NW, Washington, DC 20500", forKey: "adress")
        
        var newCity2 = NSEntityDescription.insertNewObjectForEntityForName("CityInfo", inManagedObjectContext: context)
        newCity2.setValue("Los Angeles", forKey: "city")
        newCity2.setValue("Walk of fame", forKey: "mustSeePlace")
        newCity2.setValue("Hollywood Blvd, Los Angeles, CA",forKey: "adress")
        
        
        
        var newCity3 = NSEntityDescription.insertNewObjectForEntityForName("CityInfo", inManagedObjectContext: context)
        newCity3.setValue("San Francisco", forKey: "city")
        newCity3.setValue("Golden Gate Bridge", forKey: "mustSeePlace")
        newCity3.setValue(" Golden Gate Bridge, California", forKey: "adress")
        
         
        var newCity4 = NSEntityDescription.insertNewObjectForEntityForName("CityInfo", inManagedObjectContext: context)
        newCity4.setValue("Las Vegas", forKey: "city")
        newCity4.setValue("Bellagio Water Show", forKey: "mustSeePlace")
        newCity4.setValue("3600 S Las Vegas Blvd, Las Vegas, NV 89109", forKey: "adress")
        
        
        
        var newCity5 = NSEntityDescription.insertNewObjectForEntityForName("CityInfo", inManagedObjectContext: context)
        newCity5.setValue("New York", forKey: "city")
        newCity5.setValue("Times Square", forKey: "mustSeePlace")
        newCity5.setValue("Manhattan, NY 10036", forKey: "adress")
        */

        
        /*
        var newCity6 = NSEntityDescription.insertNewObjectForEntityForName("CityInfo", inManagedObjectContext: context)
        newCity6.setValue("Chicago", forKey: "city")
        newCity6.setValue("The Bean", forKey: "mustSeePlace")
        
        
        var newCity7 = NSEntityDescription.insertNewObjectForEntityForName("CityInfo", inManagedObjectContext: context)
        newCity7.setValue("Istanbul", forKey: "city")
        newCity7.setValue("Sultan Ahmet", forKey: "mustSeePlace")
        
        var newCity8 = NSEntityDescription.insertNewObjectForEntityForName("CityInfo", inManagedObjectContext: context)
        newCity8.setValue("Paris", forKey: "city")
        newCity8.setValue("Eiffel Tower", forKey: "mustSeePlace")
        
        var newCity9 = NSEntityDescription.insertNewObjectForEntityForName("CityInfo", inManagedObjectContext: context)
        newCity9.setValue("San Diego", forKey: "city")
        newCity9.setValue("San Diego Zoo", forKey: "mustSeePlace")
        */
 
        
        facebook.addTarget(self, action: #selector(ViewController.facebookButtonFunc), forControlEvents: UIControlEvents.TouchUpInside)
        twitter.addTarget(self, action: #selector(ViewController.twitterButtonFunc), forControlEvents: UIControlEvents.TouchUpInside)
        
        
        
        
        shareSocialMedia.hidden = true
        mustSeePlace.hidden = true
        
        twitter.hidden = true
        facebook.hidden = true
        
        
       
        
        
        do{
            try context.save()
        
        }
        catch{
            print("An error occurred")
        }
        //get data from CityInfo entity
        let request = NSFetchRequest(entityName: "CityInfo")
        
        request.returnsObjectsAsFaults = false
      
        
        do
        {
             let results = try context.executeFetchRequest(request)
             //print(results)

            for result in results as! [NSManagedObject]
            {
                print(result.valueForKey("city")!)
                
                cityArray.append(String(result.valueForKey("city")!))
                
                mustSeePlaces.append(String(result.valueForKey("mustSeePlace")!))
                
                //print(result.valueForKey("adress"))
                adress.append(String(result.valueForKey("adress")!))

                
            }
            
           // print(cityArray)
           //print(mustSeePlaces)
           print(adress)
            
        }
        catch{
            print("fetch failed")
        }
    
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Controls the shake gesture:
    override func motionEnded(motion: UIEventSubtype, withEvent event: UIEvent?) {
        
        
        if event?.subtype == UIEventSubtype.MotionShake
        {
           // print("Device was shaked")
            
           let randomNumber = Int(arc4random_uniform(5))
            
            print(cityArray)
            cityLabel.text  = cityArray[randomNumber]
            
            mustPlaceLabel.text = "You should see " + mustSeePlaces[randomNumber] + "!"
            
            
             showMap.hidden = false
             shareSocialMedia.hidden = false
             mustSeePlace.hidden = false
            
            let cornerRadius : CGFloat = 5.0
            cityLabel.layer.borderWidth = 2.0
            cityLabel.layer.cornerRadius = cornerRadius
            cityLabel.layer.borderColor = UIColor.redColor().CGColor
            
        
      
        
        }
    
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue?, sender: AnyObject!) {
        
        if segue!.identifier == "goToMostPopular" {
            
           
           for element in adress
           {
                copyAdress.append(element)
            }
            
        }
        
    }
    
   
    
  


}

