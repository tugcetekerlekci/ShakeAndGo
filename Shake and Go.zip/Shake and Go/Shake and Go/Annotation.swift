
//
//  Annotation.swift
//  Shake and Go
//
//  Created by Tugce Tekerlekci on 7/7/16.
//  Copyright © 2016 Tugce Tekerlekci. All rights reserved.
//

import Foundation
import MapKit

class Annotation:NSObject,MKAnnotation
{

    
    var coordinate = CLLocationCoordinate2D()
    
    init(coordinate:CLLocationCoordinate2D) {
        self.coordinate = coordinate
   
    
    }





}
