//
//  TableViewController.swift
//  Shake and Go
//
//  Created by Tugce Tekerlekci on 7/8/16.
//  Copyright © 2016 Tugce Tekerlekci. All rights reserved.
//


import UIKit

class TableViewController: UIViewController,UITableViewDelegate {


    @IBOutlet var mustSeenPlacesTable: UITableView!
    override func viewDidLoad()
    {
        if (NSUserDefaults.standardUserDefaults().objectForKey("mustSeePlaces") != nil)
        {
            mustSeePlaces = NSUserDefaults.standardUserDefaults().objectForKey("mustSeePlaces") as! [String]
        }
        
    
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return mustSeePlaces.count
    
    }
 
    
   func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
    
        let cell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "Cell")
    
        cell.textLabel?.text = mustSeePlaces[indexPath.row]
        
        return cell
   
    
    }
    
    override func viewDidAppear(animated: Bool) {
        
        mustSeenPlacesTable.reloadData()
    
    
    
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath)
    {
                    if editingStyle == UITableViewCellEditingStyle.Delete
                    {
        
                       mustSeePlaces.removeAtIndex(indexPath.row)
                        
                        NSUserDefaults.standardUserDefaults().setObject(mustSeePlaces, forKey: "mustSeePlaces")
                        
                        mustSeenPlacesTable.reloadData()
                    }
        
        
        
    }
    



}
