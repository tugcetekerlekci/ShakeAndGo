//
//  MostPopular.swift
//  Shake and Go
//
//  Created by Tugce Tekerlekci on 7/7/16.
//  Copyright © 2016 Tugce Tekerlekci. All rights reserved.
//

import UIKit
import MapKit


var copyAdress:[String] = []

class MostPopular: UIViewController,MKMapViewDelegate {

    @IBOutlet var mapView: MKMapView!
    
    @IBOutlet var newPlace: UITextField!
    
    let regionRadius:CLLocationDistance = 1000
    let locationManager = CLLocationManager()
    
    

    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
         mapView.delegate = self
        
        for add in copyAdress
        {
            getPlacemarkFromAddress(add)
        }
        
    
    
    }
    
    
    override func viewDidAppear(animated: Bool) {
        locationAuthStatus()
    }
    
    func locationAuthStatus()
    {
        if CLLocationManager.authorizationStatus() == .AuthorizedWhenInUse
        {
            mapView.showsUserLocation = true
            
        }
            
        else
        {
            
            locationManager.requestWhenInUseAuthorization()
        }
        
    }
    
    
    
    func centerMapOnLocation(location:CLLocation)
    {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius*2, regionRadius*2)
        
        mapView.setRegion(coordinateRegion, animated: true)
        
    }
    
    
    func mapView(mapView: MKMapView, didUpdateUserLocation userLocation: MKUserLocation) {
        if let lock = userLocation.location{
            
            centerMapOnLocation(lock)
        }
    }
    
    func getPlacemarkFromAddress(address: String)
    {
        
        CLGeocoder().geocodeAddressString(address) { (placemarks: [CLPlacemark]?, error:NSError?) in
            if let marks = placemarks where marks.count>0
            {
                if let loc = marks[0].location
                {
                    
                    //we have a valid location with coordinatesss .
                    self.createAnnotationForLocation(loc)
                    
                }
                
            }
            
        }
        
    }
    
    func createAnnotationForLocation(location: CLLocation)
    {
        
        let bootcamp = Annotation(coordinate: location.coordinate)
        mapView.addAnnotation(bootcamp)
        
        
        
    }
    
    //EVERYTIME map.addAnnotation(annotion) pin drop to the map, ths funnction called automatically by the delegate.
    func mapView(mapView: MKMapView,viewForAnnotation annotation: MKAnnotation)-> MKAnnotationView?
    {
        
        if annotation.isKindOfClass(Annotation)
        {
            let annoView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "Default")
            annoView.pinTintColor = UIColor.yellowColor()
            annoView.animatesDrop = true
            return annoView
            
        }
        else if annotation.isKindOfClass(MKUserLocation)
        {
            return nil
            
        }
        
        return nil
    }
    
    @IBAction func addItem(sender: AnyObject) {
    
        
        mustSeePlaces.append(newPlace.text!)
    
        newPlace.text = ""
        
        NSUserDefaults.standardUserDefaults().setObject(mustSeePlaces, forKey: "mustSeePlaces")
        
    }
    
     
  
   

}
