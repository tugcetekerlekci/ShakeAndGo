//
//  MapView.swift
//  Shake and Go
//
//  Created by Tugce Tekerlekci on 7/7/16.
//  Copyright © 2016 Tugce Tekerlekci. All rights reserved.
//

import UIKit
import MapKit
import Social

class MapView: UIViewController,MKMapViewDelegate {

    
    @IBOutlet var facebook: UIButton!
    @IBOutlet var twitter: UIButton!
    
    @IBAction func twitterButtonFunc(sender: AnyObject) {
    
        let vc = SLComposeViewController(forServiceType: SLServiceTypeTwitter)
        vc.addURL(NSURL(string: "http://www.tugcetekerlekci.com"))
        presentViewController(vc, animated: true, completion: nil)
    
    
    
    }
    
    @IBAction func facebookButtonFunc(sender: AnyObject) {
        
        let vc = SLComposeViewController(forServiceType: SLServiceTypeFacebook)
        vc.setInitialText("Shared with Shake and Discover")
        vc.addURL(NSURL(string: "http://www.tugcetekerlekci.com"))
        
        //vc.addImage(UIImage(named: "IMG_7893.JPG")!)
        presentViewController(vc, animated: true, completion: nil)
    
    }
    
    @IBOutlet var shareOnSocialMedia: UIButton!
    
    @IBAction func shareOnSocial(sender: AnyObject) {
        
        facebook.hidden = false
        twitter.hidden = false
    
    
    }

    @IBOutlet var mapView: MKMapView!

    
    let regionRadius:CLLocationDistance = 1000
    let locationManager = CLLocationManager()
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
    
        mapView.delegate = self
        facebook.hidden = true
        twitter.hidden = true
    
    
    }
    
    override func viewDidAppear(animated: Bool) {
        locationAuthStatus()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func locationAuthStatus()
    {
        if CLLocationManager.authorizationStatus() == .AuthorizedWhenInUse
        {
            mapView.showsUserLocation = true
        
        }
        
        else
        {
        
            locationManager.requestWhenInUseAuthorization()
        }
    
    }
    
    
    
    func centerMapOnLocation(location:CLLocation)
    {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius*2, regionRadius*2)
        
        mapView.setRegion(coordinateRegion, animated: true)
    
    }
    
    
    func mapView(mapView: MKMapView, didUpdateUserLocation userLocation: MKUserLocation) {
        if let lock = userLocation.location{
        
            centerMapOnLocation(lock)
        }
    }
    
    
    

}
